#!/bin/bash
clear
ROUGE='\033[0;31m'
VERT='\033[0;32m'
NC='\033[0m'

clear
echo "Gestion du parc"|figlet
quitter=1
while [[ $quitter -ne 0 ]]
do
echo -e "\nMenu :"
echo "1) Consulter les données"
echo "2) Ajouter des données"
echo "3) Supprimer des données"
echo "4) Modifier des données"
echo "0) Retour au menu principal"
echo -e "Veuillez choisir une option :"
read choix
case $choix in 
	1 )
		bash 1-affiche.sh
		;;
	2 )
		bash 2-ajout.sh
		;;
	3 )
		bash 3-suppr.sh
		;;
	4 )
		bash 4-modif.sh
		;;
	0 )
		myGestIOnR/myGest_IOnR.sh
		;;
	* )
		echo "Erreur dans la saisie, veuillez réessayer"
		sleep 2
		;;
esac
done
