#!/bin/bash
#fichier de configuration, qui devra etre auto généré a l'installation du programme

#permet de determiner si programme sur un serveur (1) ou une machine (0). Utile pour IHM
serveur=0

