#!/bin/bash
clear
ROUGE='\033[0;31m'
VERT='\033[0;32m'
JAUNE='\033[0;33m'
NC='\033[0m'
echo "+---------------------------------------------------+"
echo "|        Installation des éléments essentiels       |"
echo "+---------------------------------------------------+"
sleep 1
apt update && apt install -y figlet lolcat net-tools
sleep 1.5
clear
echo -e "${VERT}Installation des prérequis nécessaires terminé !${NC}"
sleep 2
clear
bash /home/eleve/myGest_IOnR/myGestIOnR.sh