#!/bin/bash
clear
ROUGE='\033[0;31m'
VERT='\033[0;32m'
JAUNE='\033[0;33m'
NC='\033[0m'


echo "Bienvenu dans"|figlet
echo "MyGest IOn'R"|figlet
sleep 3
clear
echo ""
echo "Menu principal"|figlet
echo "1) Gestion du parc"
echo "2) Outils réseau"
echo "0) Quitter"
echo -e "Veuillez choisir une option :"
read choix
case $choix in 
	1 )
		bash gestParc/menuParc.sh
		;;
	2 )
		bash outilsRx/0-menuOutils.sh
		;;
	0 )
		figlet "Au revoir"
		sleep 2
		clear
		exit
		;;
	* )
		echo "Erreur dans la saisie, veuillez réessayer"
		sleep 2
		bash myGestIOnR.sh
		;;
esac



